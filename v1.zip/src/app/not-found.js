'use client';

export default function NotFound() {
    return (
        <html>
            <body className="text-center">
                <h1 className="mt-5 font-weight-semibold">
                    Something went wrong!
                </h1>
            </body>
        </html>
    );
}
